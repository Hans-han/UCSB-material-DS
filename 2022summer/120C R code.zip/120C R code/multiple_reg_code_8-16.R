library(tidyverse)
library(ggplot2)
library(ggthemes)
growth <- c(8, 10, 9, 10.3, 9.1, 12.2, 10.2, 12.6, 10.4, 13.9)
type <- rep(c("A", "B"), 5)
time <- c(-2, -2, -1, -1, 0, 0, 1, 1, 2, 2)

bacteria <- tibble(growth, type, time); bacteria

X <- matrix(c(rep(1, 10), rep(c(0,1), 5), time,
              rep(c(0,1), 5)*time), ncol = 4); X
Xt <- t(X); Xt

SSmat <- Xt %*% X; SSmat

Y <- matrix(c(growth)); Y
XYmat <- Xt %*% Y; XYmat
SSmatinv <- solve(SSmat); SSmatinv

beta_hat <- SSmatinv %*% XYmat; beta_hat

lm(data = bacteria, formula = growth ~ type + time + type*time)

# plot:

ggplot(data = bacteria, aes(time, growth,
                            color = type)) +
  geom_point() + theme_bw() +
  geom_smooth(aes(time, growth, group = type, color = type), lty = 2, method = "lm", se = F)

# predict

9.34 + 2.46 * 0 + 0.60 * 0 + 0.41 * 0
9.34 + 2.46 * 1 + 0.60 * 0 + 0.41 * 0

# hypothesis test

a_mat <- matrix(c(0, 1, 0, 0)); a_mat
at_mat <- t(a_mat); at_mat

c_val <- at_mat %*% SSmatinv %*% a_mat; c_val

# create SSE

yt_mat <- t(Y); yt_mat
SSE <- yt_mat %*% Y - (t(beta_hat) %*% XYmat); SSE

s2 <- SSE/(length(growth) - 4); s2
s <- sqrt(s2); s
at_beta <- at_mat %*% beta_hat; at_beta

t_val <- (at_beta - 0)/(s * sqrt(c_val)); t_val
pt(q = t_val, df = (length(growth) - 4), lower.tail = F)

lm(data = bacteria, formula = growth ~ type + time + type*time) %>% summary()

## 90% CI for type B at time 1

a_xstar_mat <- matrix(c(1, 1, 1, 1)); a_xstar_mat
at_xstar_mat <- t(a_xstar_mat)
at_xstar_beta <- at_xstar_mat %*% beta_hat
