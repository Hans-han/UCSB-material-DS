library(tidyverse)

# exam example

counts <- c(13, 42, 7, 38)
prob <- c(rep(0.25, 4))

npi <- sum(counts)*prob

test_stat <- sum( (counts - npi)^2/npi )
test_stat
pchisq(q = test_stat, df = 3, lower.tail = F)


chisq.test(x = counts, p = prob)


dice_outcome <- c(48, 35, 15, 3)
dice_prob <- c(dbinom(0, 3, 1/6), dbinom(1, 3, 1/6),
               dbinom(2, 3, 1/6), dbinom(3, 3, 1/6))

npi <- sum(dice_outcome)*dice_prob

test_stat <- sum( (dice_outcome - npi)^2/npi )
test_stat
pchisq(q = test_stat, df = 3, lower.tail = F)


chisq.test(x = dice_outcome, p = dice_prob)

# accident example

accident_counts <- c(32, 12, 6)
accident_prob <- c(dpois(0, lambda = 0.48),
                   dpois(1, lambda = 0.48),
                   (ppois(2, lambda = 0.48, 
                          lower.tail = F) + 
                      dpois(2, lambda = 0.48)))
# last one because probability of a Y greater than OR equal to 2
# (ie density of 2 plus prob to the right of 2)

chisq.test(accident_counts, p = accident_prob, correct = T)

npi <- sum(accident_counts)*accident_prob
test_stat <- sum( (accident_counts - npi)^2 / npi)
test_stat
pchisq(q = test_stat, df = 2, lower.tail = F)
npi

# test of independence
bike_matrix <- matrix(c(60, 54, 46, 41, 40,
                        44, 53, 57), nrow = 2,
                      byrow = T)
bike_matrix
chisq.test(bike_matrix)
