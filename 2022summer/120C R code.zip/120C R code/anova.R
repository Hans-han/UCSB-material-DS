library(tidyverse)
library(ggplot2)
library(ggthemes)

data <- tibble(company = factor(c(1:5, 1:5, 1:5, 1:5)),
               location = factor(c(rep("A", 5), rep("B", 5),
                                   rep("C", 5), rep("D", 5))),
               rate = c(736, 745, 668, 1065, 1202, 836, 725,
                        618, 869, 1172, 1492, 1384, 1214,
                        1501, 1682, 996, 884, 802, 1571,
                        1272))
data %>% 
  group_by(company) %>% 
  summarise(mean(rate))

ggplot(data, aes(x = rate)) + 
  geom_density(aes(fill=company), alpha = .3) +
  theme_bw()

data %>% 
  group_by(location) %>% 
  summarise(mean(rate))

ggplot(data, aes(x = rate)) + 
  geom_density(aes(fill=location), alpha = .3) +
  theme_bw()

ggplot(data, aes(x = factor(company), y = rate, fill = factor(location))) +
  geom_bar(stat = "Identity", width = 0.8, position = "dodge") +
  xlab("Company") + ylab("Rate") + labs(fill = "Location") +
  theme_bw()

interaction.plot(x.factor=data$company, trace.factor=data$location, 
                 response=data$rate, type='b')  


aov(rate ~ company + location, data = data) %>%
  summary()

# We can calculate the p-value manually:
pf(12.18, df1 =4, df2 = 12, lower.tail = FALSE)
pf(26.12, df1 =3, df2 = 12, lower.tail = FALSE)


# one way to construct CI:
s <- sqrt(180035/(12))
# let's look at the difference between the average rate of company 4 and company 5

data %>% 
  group_by(company) %>% 
  summarise(mean = mean(rate)) %>% 
  View()

qt(0.025, df = 12)

(1251.5 - 1332.0) + (2.178813)*s*sqrt(2/5)
(1251.5 - 1332.0) - (2.178813)*s*sqrt(2/5)
# we've essentially discovered that there is no significant diff between those two, but there IS a significant difference between these two - -company one and company 5:
(1015.0 - 1332.0) + (2.178813)*s*sqrt(2/5)
(1015.0 - 1332.0) - (2.178813)*s*sqrt(2/5)


aov(rate ~ company + location, data = data) %>%
  coefficients()
lm(rate ~ company + location, data = data) %>% 
  summary()
